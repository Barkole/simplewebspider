/* This file is part of the db4o object database http://www.db4o.com

Copyright (C) 2004 - 2009  Versant Corporation http://www.versant.com

db4o is free software; you can redistribute it and/or modify it under
the terms of version 2 of the GNU General Public License as published
by the Free Software Foundation and as clarified by Versants' GPL 
interpretation policy, available at
http://www.db4o.com/about/company/legalpolicies/gplinterpretation/
Alternatively you can write to Versant Corporation
255 Shoreline Drive, Suite 450, Redwood City, CA 94065, USA

db4o is distributed in the hope that it will be useful, but WITHOUT ANY
WARRANTY; without even the implied warranty of MERCHANTABILITY or
FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
for more details.

You should have received a copy of the GNU General Public License along
with this program; if not, write to the Free Software Foundation, Inc.,
59 Temple Place - Suite 330, Boston, MA  02111-1307, USA. */
package com.db4o.cs.internal.config;

import com.db4o.*;
import com.db4o.config.*;
import com.db4o.cs.*;
import com.db4o.cs.internal.*;
import com.db4o.ext.*;
import com.db4o.foundation.network.*;
import com.db4o.internal.*;

/**
 * @exclude
 * 
 * @deprecated Use Db4oClientServer
 */
public class ClientServerFactoryImpl implements ClientServerFactory{

	/**
	 * @deprecated Use {@link Db4oClientServer#openClient}
	 */
	public ObjectContainer openClient(Configuration config, String hostName,
			int port, String user, String password,
			NativeSocketFactory socketFactory) throws Db4oIOException,
			OldFormatException, InvalidPasswordException {
		if (user == null || password == null) {
			throw new InvalidPasswordException();
		}
		Config4Impl.assertIsNotTainted(config);
		NetworkSocket networkSocket = new NetworkSocket(socketFactory, hostName, port);
		return new ClientObjectContainer(config, networkSocket, user, password, true);
	}

	/**
	 * @deprecated Use {@link Db4oClientServer#openServer}
	 */
	public ObjectServer openServer(Configuration config,
			String databaseFileName, int port, NativeSocketFactory socketFactory)
			throws Db4oIOException, IncompatibleFileFormatException,
			OldFormatException, DatabaseFileLockedException,
			DatabaseReadOnlyException {
		LocalObjectContainer container = (LocalObjectContainer)Db4o.openFile(config,databaseFileName);
        if(container == null){
            return null;
        }
        synchronized(container.lock()){
            return new ObjectServerImpl(container, port, socketFactory);
        }
	}

}
