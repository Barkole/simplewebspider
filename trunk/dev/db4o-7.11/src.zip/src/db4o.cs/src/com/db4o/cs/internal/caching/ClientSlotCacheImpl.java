/* This file is part of the db4o object database http://www.db4o.com

Copyright (C) 2004 - 2009  Versant Corporation http://www.versant.com

db4o is free software; you can redistribute it and/or modify it under
the terms of version 2 of the GNU General Public License as published
by the Free Software Foundation and as clarified by Versants' GPL 
interpretation policy, available at
http://www.db4o.com/about/company/legalpolicies/gplinterpretation/
Alternatively you can write to Versant Corporation
255 Shoreline Drive, Suite 450, Redwood City, CA 94065, USA

db4o is distributed in the hope that it will be useful, but WITHOUT ANY
WARRANTY; without even the implied warranty of MERCHANTABILITY or
FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
for more details.

You should have received a copy of the GNU General Public License along
with this program; if not, write to the Free Software Foundation, Inc.,
59 Temple Place - Suite 330, Boston, MA  02111-1307, USA. */
package com.db4o.cs.internal.caching;

import static com.db4o.foundation.Environments.*;

import java.util.*;

import com.db4o.*;
import com.db4o.cs.caching.*;
import com.db4o.events.*;
import com.db4o.internal.*;

public class ClientSlotCacheImpl implements ClientSlotCache {

	private final TransactionLocal<Map<Integer, ByteArrayBuffer>> _cache = new TransactionLocal<Map<Integer, ByteArrayBuffer>>() {
		public java.util.Map<Integer, ByteArrayBuffer> initialValueFor(Transaction transaction) {
			return new HashMap();
		};
	};
	
	public ClientSlotCacheImpl() {
		final EventRegistry eventRegistry = EventRegistryFactory.forObjectContainer(my(ObjectContainer.class));
		eventRegistry.activated().addListener(new EventListener4<ObjectInfoEventArgs>() {
			public void onEvent(Event4 e, ObjectInfoEventArgs args) {
				purge((Transaction) args.transaction(), (int)args.info().getInternalID());
            }
		});
	}
	
	public void add(Transaction provider, int id, ByteArrayBuffer slot) {
		cacheOn(provider).put(id, slot);
    }

	public ByteArrayBuffer get(Transaction provider, int id) {
		final ByteArrayBuffer buffer = cacheOn(provider).get(id);
		if (null == buffer) {
			return null;
		}
		buffer.seek(0);
		return buffer;
    }
	
	private void purge(Transaction provider, int id) {
		cacheOn(provider).remove(id);
	}

	private Map<Integer, ByteArrayBuffer> cacheOn(Transaction provider) {
		return provider.get(_cache).value;
	}
}
